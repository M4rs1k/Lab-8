////
////  Task+CoreDataProperties.swift
////  CustomTabBarApp
////
////  Created by Ramzan on 01.04.2024.
////
////
//
//import Foundation
//import CoreData
//
//
//extension Task {
//
//    @nonobjc public class func fetchRequest() -> NSFetchRequest<Task> {
//        return NSFetchRequest<Task>(entityName: "Task")
//    }
//
//    @NSManaged public var checkin: String?
//    @NSManaged public var checkout: String?
//    @NSManaged public var date: Date?
//
//}
//
//extension Task : Identifiable {
//
//}
