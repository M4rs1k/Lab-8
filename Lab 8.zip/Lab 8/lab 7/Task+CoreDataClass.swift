//
//  Task+CoreDataClass.swift
//  CustomTabBarApp
//
//  Created by Ramzan on 01.04.2024.
//
//

import Foundation
import CoreData

@objc(Task)
public class Task: NSManagedObject {

}
